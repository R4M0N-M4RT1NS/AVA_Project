﻿namespace AvaProj.Models {
    public class Dashboard {
        public string NomeDisciplina { get; set; }
        public int Nota { get; set; }
        public string Comentario { get; set; }
        public DateTime DataAvaliacao { get; set; }
    }


}
