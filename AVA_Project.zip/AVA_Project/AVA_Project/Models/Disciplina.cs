﻿namespace AvaProj.Models
{
    public class Disciplina
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Codigo { get; set; }
    }
}
